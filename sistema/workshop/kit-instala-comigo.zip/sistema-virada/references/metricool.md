# Metricool · Manual técnico (leia SEMPRE antes de qualquer chamada ao Metricool)

Este arquivo existe porque as chamadas ao Metricool têm pegadinhas que fazem tudo falhar em silêncio.
Siga à risca. Nada aqui aparece pra pessoa: é bastidor seu.

## Antes de tudo: o conector está ligado?

Verifique se as ferramentas do Metricool estão disponíveis na sessão (`getBrandSettings`,
`getAnalyticsDataByMetrics`, `getScheduledPosts`, `getBestTimeToPostByNetwork`, `createScheduledPost`).
Se NÃO estiverem: não finja que funcionou e não pule em silêncio. Diga pra pessoa em 1 frase que o
Metricool ainda não está conectado ao Claude (Configurações > Conectores > Metricool) e siga pelo
caminho manual (legendas prontas pra colar). Se estiverem: USE de verdade, nada de dizer "depois eu
puxo".

## O brandId (a chave de tudo)

Toda chamada precisa do `brandId` da conta DA PESSOA. Descubra via `getBrandSettings` (lista as marcas
da conta conectada) na primeira vez, confirme com a pessoa se houver mais de uma marca, e **guarde no
`perfil.md`** (linha `brandId: XXXXXXX`). Nas próximas vezes, leia do perfil. NUNCA use brandId de
exemplo ou de outra pessoa.

## O formato de data (a pegadinha nº 1)

Os campos de data exigem **ISO 8601 COMPLETO, com milissegundos e fuso**:

```
2026-07-08T00:00:00.000-03:00
```

Data crua tipo `2026-07-08` dá ERRO DE PARSE. E os nomes dos campos mudam por ferramenta:
- **Analytics** (`getAnalyticsDataByMetrics`): usa `from` / `to`.
- **Agendados** (`getScheduledPosts`): usa `fromDate` / `toDate`.

Timezone: sempre `America/Sao_Paulo` (a não ser que a pessoa more em outro fuso; pergunte uma vez e
guarde no perfil).

## Métricas úteis do Instagram (códigos)

Reels (últimos 30 dias é um bom período padrão):
- `IGRE01` data · `IGRE03` legenda · `IGRE06` url · `IGRE23` views · `IGRE12` salvos ·
  `IGRE07` comentários · `IGRE21` compartilhamentos

Evolução de seguidores:
- `IGEV01` total de seguidores no dia · `IGEV03` saldo do dia (ganho/perda)

Se precisar de outras redes ou métricas, chame `getAnalyticsAvailableMetrics` primeiro e escolha os
códigos de lá (não invente código).

## Agendar de verdade (createScheduledPost)

- Uma chamada POR REDE, com o `brandId` da pessoa, a data no formato ISO completo acima, a legenda
  adaptada pra rede e o link do vídeo.
- **O vídeo precisa estar num link público da internet** (Drive/Dropbox). No Google Drive, o link tem
  que estar como "qualquer pessoa com o link pode ver". Erro tipo "Failed to normalize media" =
  problema de PERMISSÃO do link, não de formato do vídeo. Corrija a permissão antes de mexer em formato.
- Vídeo tem que ser mp4. Vídeo de iPhone (.mov/HEVC) precisa converter antes: resolva nos bastidores,
  sem tecniquês com a pessoa.
- Melhor horário: `getBestTimeToPostByNetwork` (brandId + timezone). Sem conector, sugira horários
  típicos do nicho e pergunte.
- **REGRA INEGOCIÁVEL: preview no chat + "sim" explícito da pessoa ANTES de qualquer
  `createScheduledPost`. Nada sobe sem o OK.**

## Depois de qualquer operação

- Agendou? Confirme rede por rede (dia + hora) e atualize a fila do `dados.js` do dashboard (se existir).
- Puxou análises? Ofereça salvar um resumo em `meu-sistema/materiais/` (vira matéria-prima do perfil).
- Falhou? Diga em português de gente o que houve e o plano B. Nunca falhe em silêncio.
