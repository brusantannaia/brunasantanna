# Comandos do dia a dia

Estes comandos funcionam a qualquer momento, mesmo depois dos módulos concluídos. Leia este arquivo
quando a pessoa pedir um deles. As Regras de Ouro do SKILL.md valem o tempo todo (em especial: nada de
rede social sem o "sim" dela). **Antes de qualquer chamada ao Metricool, leia `references/metricool.md`
(formato de data, brandId, códigos de métrica): sem ele as chamadas falham.**

## "me dá pautas" / "roda meu radar"

O radar de pautas, igual ao da Bruna.

**Se o `meu-sistema/radar-diario.md` já existe** (Módulo 8 feito): leia e EXECUTE aquele arquivo, ele é
o manual da rotina personalizada da pessoa. É o mesmo radar que roda agendado.

**Se ainda não existe** (versão sob demanda):
1. Leia `perfil.md` (pilares, inspirações/concorrentes, fontes do nicho, meta) e `base-conteudo.md`
   (pra NUNCA repetir pauta já feita).
2. **Pesquise de verdade**: busque na web o que os criadores/concorrentes dela postaram de mais quente
   recentemente e o que saiu de novidade nas fontes do nicho dela. Se o Metricool estiver ligado, puxe
   também os números dos últimos posts DELA (o que performou melhor), seguindo `references/metricool.md`.
3. Entregue **5 pautas** com: título, ângulo em 1 frase (por que agora), a fonte da ideia (qual criador
   ou site inspirou) e a palavra-chave sugerida. Priorize pautas que cruzam: assunto quente no nicho ×
   pilar dela × o que já performou pra ela.
4. Termine oferecendo: "quer que eu rode o motor com alguma dessas?" e, se o Módulo 8 ainda não foi
   feito, "quer que eu deixe esse radar rodando sozinho todo dia? É o Módulo 8, leva 5 minutos".

## "analisa minha semana" / "como foi meu conteúdo"

Com o Metricool ligado, puxe os resultados dos posts recentes dela, compare com a META de 90 dias do
`perfil.md` (tá no caminho? quanto falta?), atualize o dashboard (`dados.js`: resultados + meta) e feche
com 1 recomendação prática ("esse formato tá performando, dobra a aposta" / "esse horário rendeu mais").
Sem o Metricool, peça os prints dela e faça a mesma leitura.

## "monta meu dashboard"

Se o dashboard ainda não existe, rode o Módulo 6 agora (leia `references/modulos-6-8.md`: crie o painel
a partir dos moldes em `assets/` e semeie os dados). Se já existe, trate como "atualiza meu dashboard".

## "atualiza meu dashboard" / "atualiza minha meta"

Puxe os dados (Metricool se ligado, senão base-conteudo + o que ela contar) e reescreva o `dados.js` por
ela: resultados, fila e meta (inclusive o número atual da meta, se ela tiver novidade).

## "refazer meu perfil"

Reabra o Módulo 1 (leia `references/modulos-0-2.md`): antes de perguntar, releia a pasta
`meu-sistema/materiais/` (a pessoa pode ter jogado material novo lá: análises do Metricool, do Manus,
posts, e-mails). Depois, uma pergunta por vez, mostrando a resposta antiga pra confirmar/trocar.
Reescreva `perfil.md` e ofereça regenerar o motor com o perfil novo.

## "analisa meu perfil"

Rode a Parte A do Módulo 1 avulsa (leia `references/modulos-0-2.md`), começando SEMPRE pela leitura da
pasta `meu-sistema/materiais/`.

## "guarda isso nos meus materiais" (ou a pessoa manda um arquivo/análise avulsa)

Se a pessoa mandar uma análise nova (Metricool, Manus, prints), um texto dela, ou qualquer material do
negócio fora de hora: salve dentro de `meu-sistema/materiais/` com um nome claro (ex.:
`analise-metricool-2026-07.md`) e diga que ficou guardado pra próxima análise de perfil.
