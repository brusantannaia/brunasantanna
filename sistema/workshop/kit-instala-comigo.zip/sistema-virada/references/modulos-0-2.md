# Módulos 0 a 2 · Preparo, Processo e Motor

Leia este arquivo quando a pessoa estiver em qualquer um destes módulos. As Regras de Ouro do SKILL.md
valem o tempo todo (uma coisa por vez, nunca aceite resposta vaga, faça por ela o que der).

## MÓDULO 0 · PREPARO

Objetivo: garantir o básico e criar a casa do sistema.

1. Pergunte **como a pessoa quer ser chamada** (o nome dela entra no progresso e no motor).
2. Pergunte, leve, se ela já tem a **conta paga do Claude** e o **app do Claude** no computador.
   Se não tiver certeza, ajude a checar.
3. **Você cria** a pasta `meu-sistema/` dentro de **Documentos** do usuário (local padrão; se a pessoa
   preferir outro lugar, respeite) e, dentro dela:
   - o `progresso.md` (formato do SKILL.md, tudo desmarcado), já com o nome dela e o **caminho completo
     da pasta** anotados;
   - a subpasta `meu-sistema/materiais/` (a "gaveta de matéria-prima" do sistema).
4. **Convide a pessoa a encher a gaveta de materiais.** Explique em português de gente: "essa pasta
   `materiais` é onde você joga tudo que me ajuda a te conhecer. Quanto mais você puser aí, mais o seu
   sistema fica com a SUA cara." Dê exemplos concretos do que serve:
   - **análises prontas do perfil**: relatórios do Metricool, análises do Manus, prints de métricas do
     Instagram;
   - **coisas que você escreveu**: posts antigos (mesmo os que não bombaram), legendas, e-mails que você
     mandou pra clientes, textos do site, a bio;
   - **material do negócio**: apresentação, portfólio, lista de serviços, "sobre mim", PDFs.
   Diga que pode arrastar os arquivos pra pasta agora ou a qualquer momento: "o sistema lê tudo que
   estiver lá na hora de montar (e remontar) o seu perfil". Não trave o módulo esperando: se ela não tem
   nada agora, siga em frente.
5. Verifique que a pasta, o progresso e a subpasta `materiais/` existem. Marque o Módulo 0 e comemore:
   "A casa do seu sistema tá de pé. Bora definir o seu processo."

## MÓDULO 1 · DEFINIR O PROCESSO (o coração do método)

Objetivo: antes de montar qualquer coisa, entender o processo da pessoa a partir de DADO, não de achismo.
Sai daqui com três ingredientes: **pilares, tom de voz real e formato-âncora**. Salve tudo em
`meu-sistema/perfil.md`.

Explique em 1 frase por que este módulo vem primeiro: "A gente não automatiza o que não sabe descrever.
Então antes de montar o motor, a gente descobre exatamente o que funciona no SEU perfil."

### Parte A · A auditoria do perfil

1. **PRIMEIRO: leia a pasta `meu-sistema/materiais/`.** Antes de pedir qualquer coisa, olhe o que já está
   lá: análises do Metricool ou do Manus, posts, e-mails, textos, bio, apresentações. Leia TUDO que for
   legível e avise a pessoa do que você encontrou: "achei aqui a sua análise do Metricool e uns posts
   seus, já vou usar". Análises prontas (Metricool/Manus) valem ouro: elas já trazem pilares, horários e
   o que performou. E-mails e textos são a voz REAL da pessoa: use como fonte de exemplos de tom.
2. Se a gaveta estiver vazia (ou rala), peça material pelos caminhos abaixo, do mais fácil ao mais
   completo (aceite qualquer combinação, e ofereça salvar o que ela mandar dentro de `materiais/` pra
   ficar guardado):
   - **Colar aqui os 3 a 5 posts que mais performaram** (texto/legenda). É o caminho padrão.
   - **Mandar documentos que dão contexto do negócio:** um "sobre mim", a apresentação/portfólio, a
     lista de serviços, print da bio, um PDF, o site. Peça ativamente: "se você tiver algum material do
     seu negócio, me manda ou joga na pasta materiais que eu leio, ajuda muito."
   - **Puxar do Metricool automaticamente (se ela já usa):** se o conector do Metricool estiver ligado,
     você NÃO precisa pedir pra ela colar nada. **Leia `references/metricool.md` ANTES de chamar
     qualquer coisa** (formato de data, brandId, códigos de métrica) e puxe de verdade: os **melhores
     posts / engajamento** (`getAnalyticsDataByMetrics`), o **melhor horário por rede**
     (`getBestTimeToPostByNetwork`) e as **configurações da marca** (`getBrandSettings`). Puxou? Mostre
     1 achado concreto pra pessoa ("teu post de X foi o campeão do mês") e salve o resumo em
     `materiais/`. Se o conector não estiver ligado ainda, tudo bem: ela conecta no Módulo 5 e aí você
     reanalisa.
   - Ou uma análise do **Manus**, se ela usa.
3. Se ela não tem posts nem material ainda (está começando do zero), sem drama: fale com naturalidade
   ("tranquilo, a gente constrói do zero na entrevista, e daqui a um mês você refaz essa análise com os
   seus primeiros posts") e construa os ingredientes por perguntas extras:
   - **Tom com exemplos:** "me escreve aqui, do seu jeito, 2-3 frases como você explicaria o que você faz
     pra um cliente" (essas frases viram os exemplos de tom).
   - **Pilares:** "quais 3 assuntos você quer que as pessoas lembrem quando pensarem em você?" (sugira
     opções do nicho dela se travar).
   - **Formato-âncora:** "qual formato você mais se imagina fazendo com constância?" (sem dado, vale a
     preferência dela).
4. Com o material na mão, **você extrai e devolve** um diagnóstico curto:
   - **Pilares:** os 3 a 5 temas centrais que se repetem nos melhores posts (a cara dela).
   - **Tom de voz:** como ela realmente escreve, com **2-3 frases REAIS dela** citadas como exemplo
     (dos posts, e-mails ou textos da pasta materiais).
   - **Formato-âncora:** o formato que mais funciona no perfil dela (Reel? carrossel? texto?).
   - **Padrões PRÓPRIOS (o ingrediente que faz o motor ser DELA):** se houver análise profunda (Manus,
     Metricool, ou os próprios posts em quantidade), extraia também COMO os melhores conteúdos dela são
     construídos: o jeito de gancho que funciona pra ela, a estrutura de roteiro dos Reels que
     performaram, o formato de carrossel dela (quantos slides, como abre, como fecha), duração, ritmo.
     Registre como regras concretas ("os Reels dela que bombam abrem com pergunta direta e têm menos de
     30 segundos"). Esses padrões vão SUBSTITUIR as regras padrão do template do motor no Módulo 2.
     Sem análise, sem problema: as regras padrão do template assumem, e daqui a um tempo ela roda uma
     análise e vocês refinam.
5. Mostre o diagnóstico e peça confirmação: "Li o seu perfil assim, faz sentido? O que eu ajustaria?".
   Só siga depois do "tá certo". Se algo veio vago, aplique a Regra de Ouro 4 (puxe exemplo).

### Parte B · As perguntas do processo

Antes de começar, ofereça o ritmo: "quer que eu pergunte uma por uma, ou prefere blocos de 3-4 perguntas
pra ir mais rápido (gasta menos do seu limite de uso)?". Respeite a escolha (no modo em blocos, no
máximo 4 por mensagem, numeradas). Vá salvando em `meu-sistema/perfil.md`. Se alguma resposta já
estiver clara pelos materiais que você leu, confirme em vez de perguntar do zero ("pelos seus posts, seu
tom é bem direto e bem-humorado, confere?").

1. **Você sabe o seu tom de voz?** (se hesitar, use os exemplos reais que você extraiu na Parte A).
2. **Qual formato é o seu âncora, o carro-chefe?** (Reel, carrossel, ou texto? o que rende mais pra você?)
3. **Quais redes você usa hoje?** (Instagram, TikTok, YouTube, LinkedIn, Threads).
4. **Você tem um jeito de roteiro que se repete?** (se não, tudo bem, o motor vai te dar um).
5. **Quem são os 3 a 5 criadores ou concorrentes que você acompanha?** (perfis do seu nicho que postam
   coisa boa: são o "radar" do seu sistema, a gente vai olhar o que funciona pra eles e adaptar pro seu
   tom. Peça os @ ou nomes.)
6. **Onde nascem as novidades do seu nicho?** (sites, portais, newsletters, canais que ditam o assunto.
   Ajude com exemplos do nicho dela: nutrição tem os portais de saúde, imóveis tem os índices do mercado,
   moda tem as semanas de moda. No nicho de IA da Bruna, por exemplo, são os sites da Anthropic e da
   OpenAI. Anote 2-3 fontes.)
7. **Qual é a sua META de conteúdo pra 90 dias, e quanto você tem HOJE?** (um número que dá pra medir:
   seguidores, posts por semana, clientes vindos do conteúdo. Anote o ALVO e o número ATUAL: os dois vão
   pro painel, na barra de progresso. Se ela disser algo vago tipo "crescer", lapide: "crescer quanto?
   até quando? e hoje você tá com quanto?".)

Ao final, salve `meu-sistema/perfil.md` organizado (pilares, tom com exemplos, formato-âncora, padrões
próprios quando houver, redes, inspirações/concorrentes, fontes do nicho, meta de 90 dias, e uma linha
"materiais lidos:" listando o que você usou da pasta) e leia um resumo de 3-4 linhas pra confirmar. Verifique, marque o Módulo 1, comemore:
"Pronto, seu processo tá desenhado. Agora a gente transforma isso num motor."

## MÓDULO 2 · CONSTRUIR O MOTOR

Objetivo: entrevistar fundo, gerar a skill personalizada do motor no nível profissional, instalar e testar.

Explique em 1 frase: "o motor é o que pega UMA ideia sua e devolve conteúdo pronto pra várias redes, no
seu tom. Ele só fica bom se te conhecer de verdade, então vou te entrevistar fundo. Responde com exemplo
real, não com resposta bonita."

### Parte A · A entrevista funda

Ofereça o ritmo de novo (uma por uma, ou blocos de 3-4 pra economizar o limite de uso; se a pessoa já
escolheu no Módulo 1, mantenha a escolha dela). Estas perguntas alimentam os placeholders do motor.
Aplique a Regra de Ouro 4 em CADA uma: resposta vaga, puxe exemplo antes de seguir. O que já estiver
respondido pelos materiais/perfil, confirme em vez de perguntar de novo.

1. **Seu negócio: como ele chama e o que você vende/oferece?** (capture o nome; se não tiver, use o nome
   da pessoa, ex.: "Consultoria da Ana").
2. **Quem é o seu público, em uma frase?** (afunile: quem é, momento de vida, o que quer).
3. **As 2-3 maiores dores ou desejos desse público?** (peça exemplo: "o que um cliente te fala
   frustrado?"). Vira gancho de conteúdo.
4. **As objeções que você mais escuta** ("é caro", "não tenho tempo", "será que funciona pra mim?").
   Viram conteúdo que quebra objeção.
5. **Uma história ou resultado SEU de que você tem orgulho** (vira prova social; toda pessoa tem uma,
   ajude a achar).
6. **Palavras que você USA muito e palavras que você EVITA** (é o que faz o texto soar como você; se você
   leu e-mails e posts na pasta materiais, proponha uma lista extraída de lá pra ela confirmar).
7. **Um criador cujo estilo você admira** (só pra entender a vibe, não pra copiar; a resposta entra como
   nota de estilo junto do TOM no motor, ex.: "vibe de referência: didático e bem-humorado como fulano").
8. **Confirma a meta:** relembre a meta de 90 dias que ela deu no Módulo 1 ("sua meta continua sendo X,
   partindo de Y?") e ajuste se mudou.

### Parte B · Gerar a skill do motor

**Você cria** `meu-sistema/meu-motor/SKILL.md` usando o template em `assets/template-motor.md` (leia o
arquivo na hora de gerar), preenchendo TODOS os placeholders com o perfil (Módulo 1) e a entrevista
(Parte A). Preencha de verdade: nada de placeholder sobrando, com as duas exceções descritas no próprio
template ({PALAVRA} e {CAMINHO_BASE}). Adapte as regras de formato às redes e ao formato-âncora da pessoa
(não force blog se ela não tem site; priorize o formato-âncora dela).

**BARRA DE QUALIDADE (não negocie isto): o motor gerado é o produto principal do workshop.** Ele precisa
sair COMPLETO, no nível do motor profissional da Bruna. Isso significa manter TODAS as seções do
template: o fluxo em duas etapas (âncora primeiro, aprovação, depois o resto), os 3 modos de entrada,
a regra da palavra-chave, as regras de linguagem, o checklist de cada formato, o "me dá as ideias da
semana", o registro na base e o checklist final. NUNCA resuma o template pra "contexto + formatos".
Confira antes de instalar: se o SKILL.md gerado ficou com menos de 150 linhas, você cortou coisa demais;
volte e complete. Um motor raso aqui é a diferença entre o aluno ter um sistema e ter um brinquedo.

**E o molde é andaime, não fôrma.** Se o `perfil.md` tem PADRÕES PRÓPRIOS (extraídos da análise do
Manus, do Metricool ou dos posts dela no Módulo 1), REESCREVA as seções de formato do template com os
padrões DELA: o gancho do jeito que funciona pra ela, a estrutura de roteiro dela, o carrossel do
tamanho e do jeito dela. As regras que vêm no template são o padrão profissional de partida pra quem
ainda não tem dados, não uma verdade universal. O motor precisa sair com a assinatura DELA, não com a
de outra pessoa.

**Depois de gerar, empacote também o arquivo de backup:** crie `meu-sistema/meu-motor.skill`, que é a
pasta `meu-motor` compactada em zip com a extensão `.skill` (no Windows, use o PowerShell:
`Compress-Archive` da pasta e renomeie de `.zip` pra `.skill`; no Mac, `zip -r`). Explique pra pessoa em
1 frase: "esse arquivo é o seu motor empacotado, o seu backup: se você trocar de computador ou quiser
reinstalar, é só ele." A instalação de verdade é a da Parte C (a pasta na pasta de skills); o `.skill` é
a cópia de segurança portátil.

### Parte C · Instalar (o passo mais delicado, atenção redobrada)

1. Explique: "instalar a skill quer dizer copiar a pasta `meu-motor` pra pasta de skills do Claude, pra
   ele passar a conhecer o seu motor."
2. **Tente fazer VOCÊ MESMO:** copie `meu-motor` pra pasta de skills (Windows:
   `C:\Users\SEU-USUARIO\.claude\skills\`; Mac: `~/.claude/skills/`). Só peça pra pessoa fazer se você
   não conseguir, e aí guie um passo por vez.
3. **ANTES de pedir o reinício, salve o progresso:** atualize o `progresso.md` com "Onde parei: motor
   copiado pra pasta de skills; falta testar numa conversa nova". Assim, se a pessoa fechar o Claude e
   voltar perdida, você retoma exatamente daqui.
4. **VALIDE de verdade:** confira lendo que `...\skills\meu-motor\SKILL.md` existe no destino e está
   preenchido. Peça pra pessoa fechar e abrir o Claude e testar numa conversa NOVA: "escreve: roda o
   motor com o tema [qualquer coisa]. Se ele responder já no seu tom, tá instalado." Não marque como
   concluído sem essa validação.

### Parte D · O teste (a primeira rodada)

Rode UM teste real. Peça um tema simples do negócio dela e gere a **primeira rodada** com o motor, no
formato-âncora + os outros formatos das redes dela. Seja transparente: "essa rodada eu tô rodando aqui de
amostra; o teste de que o SEU motor ficou instalado é o da conversa nova". Registre o resumo no topo de
`meu-sistema/base-conteudo.md` (crie se não existir).

Verifique: o `SKILL.md` existe no destino e está preenchido? A rodada saiu? Foi pra base? Marque o Módulo
2, comemore: "Seu motor tá vivo. Uma ideia virou conteúdo com a sua cara."
