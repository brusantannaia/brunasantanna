# Módulos 3 a 5 · Edição, Formatos e Distribuição

Leia este arquivo quando a pessoa estiver em qualquer um destes módulos. As Regras de Ouro do SKILL.md
valem o tempo todo. **No Módulo 5 (e em qualquer chamada ao Metricool), leia ANTES o
`references/metricool.md`: é ele que tem o formato de data, o brandId e os códigos que fazem as
chamadas funcionarem. Sem ele, as chamadas falham e a pessoa fica sem o agendamento.**

## MÓDULO 3 · EDIÇÃO DE VÍDEO

Objetivo: instalar a skill de edição e ensinar o modelo conversacional (o céu é o limite).

1. Explique: "criar o conteúdo é metade. A outra é o vídeo ficar bom. E você não precisa de ferramenta
   complicada: você **conversa** com o Claude."
2. **Instale a skill de edição** (a pasta `edita-meu-video`, que veio no kit do workshop): primeiro
   PROCURE a pasta do kit nos lugares comuns (Downloads, Desktop, Documentos). Se não achar, pergunte:
   "onde você salvou o kit do workshop?". Achou: copie `edita-meu-video` pra pasta de skills, do mesmo
   jeito do motor. Se não achar o kit de jeito nenhum, não trave: peça pra pessoa arrastar a pasta pro
   chat, ou diga "sem estresse, por enquanto é só me pedir 'edita esse vídeo' que eu mesmo edito por
   aqui" e siga o módulo. Valide que `...\skills\edita-meu-video\SKILL.md` existe no destino (quando
   houver cópia).
3. Ensine o recado central, que é o mais importante deste módulo: **"o céu é o limite. Fala com o Claude,
   pede o que você quiser, manda referência."** Dê exemplos: "quero um corte mais rápido", "põe legenda
   embaixo", "vi um Reel que amei, quero nesse estilo, olha a referência". A skill é o ponto de partida,
   não a prisão.
4. Se a pessoa quiser, faça um teste com um vídeo dela. Marque o Módulo 3, comemore.

## MÓDULO 4 · EXPANDIR FORMATOS

Objetivo: mostrar que um input vira vários formatos, adaptados às redes dela.

1. Rode o motor num tema e mostre saírem os formatos das redes DELA (carrossel, LinkedIn, TikTok, etc.).
2. **Seja honesto sobre o carrossel:** "o motor te dá o texto slide a slide, prontinho. O design ainda é
   você que monta, no seu Canva. Se você já tem um template de carrossel, é só encaixar o texto. Metade
   do trabalho, a de escrever, já sai resolvida."
3. Marque o Módulo 4, comemore: "Um input, vários formatos. Sua semana de conteúdo em minutos."

## MÓDULO 5 · DISTRIBUIÇÃO E AGENDAMENTO (Metricool)

Objetivo: conectar a distribuição e **agendar de verdade** um post de teste. Aqui a pessoa põe a mão na
conexão, guie clique a clique, um passo por vez.

Explique: "o Metricool é grátis e agenda seus posts em várias redes de uma vez. A gente conecta ele ao
Claude pra você agendar só conversando comigo, sem abrir dez telas."

Se a pessoa não quiser criar a conta agora, respeite: "tranquilo, deixa a distribuição manual por
enquanto: eu preparo as legendas prontas e você cola na rede. Quando quiser automatizar, é só me falar
'quero conectar o Metricool'". Marque o módulo como pulado no progresso e siga pro Módulo 6.

### Parte A · Conectar (a pessoa faz, você guia)
1. Criar conta grátis em `metricool.com`.
2. Conectar SÓ as redes que a pessoa usa (do `perfil.md`). Avise: "pro Instagram funcionar, a conta
   precisa ser profissional (business/creator). Se a sua é pessoal, dá pra trocar de graça nas
   configurações do Instagram, e eu te explico como."
3. Conectar o Metricool ao Claude: no app do Claude, **Configurações > Conectores**, buscar **Metricool**,
   ativar. Guie onde clicar.

Quando conectar, **TESTE na hora que funcionou de verdade** (não dê o módulo por feito sem isso):
descubra o `brandId` da conta DELA via `getBrandSettings` (guarde no `perfil.md`; nunca use o de outra
pessoa) e faça UMA chamada real de leitura, ex.: `getBestTimeToPostByNetwork`, mostrando pra pessoa o
resultado ("olha, o teu melhor horário no Instagram é X"). Siga o `references/metricool.md` à risca
(formato de data ISO completo com fuso!). Bônus: com o conector ligado, ofereça salvar um relatório dos
melhores posts dela dentro de `meu-sistema/materiais/` (vira matéria-prima pra análises futuras).

### Parte B · O comando do dia a dia: "distribui esse vídeo"

Sempre que a pessoa disser **"distribui esse vídeo: [link]"** (ou variação), rode este fluxo. É o jeito
oficial de publicar pelo sistema.

1. **O vídeo precisa estar num link que a internet acessa.** O Metricool não lê o computador dela. Um
   jeito fácil: subir no **Google Drive** ou **Dropbox** e me mandar o link. Se ela mandar um arquivo do
   computador, ajude a subir e a pegar o link. (Nada de caminho `C:\...`.) No Drive, o link precisa estar
   como "qualquer pessoa com o link pode ver"; se o agendamento falhar com erro de mídia, o problema
   quase sempre é essa permissão, não o formato.
2. **Formato do vídeo, resolvido nos bastidores.** Vídeo de iPhone costuma vir num formato que o Metricool
   não aceita. Isso é problema SEU, não dela: se der pra ajeitar aqui, você ajeita calado; se não der,
   diga em português de gente "seu vídeo precisa de um ajustezinho de formato, me manda que eu cuido" ou
   oriente ela a exportar como vídeo comum. **NUNCA fale nome de programa técnico com ela.**
3. **Tema e legenda.** Pergunte o tema em 1 frase (ou reaproveite da `base-conteudo.md`) e monte a legenda
   adaptada pra CADA rede dela, seguindo as regras do motor (gancho na linha 1, CTA com palavra-chave,
   hashtags conforme a rede; YouTube com título e #Shorts; Threads curto, de conversa, sem lista de
   hashtags).
4. **Melhor horário.** Se ela não disser quando, pegue o melhor horário de cada rede com
   `getBestTimeToPostByNetwork` (o `brandId` dela, timezone `America/Sao_Paulo`). Sem o conector ligado,
   sugira horários típicos do nicho dela (ex.: almoço e início da noite) e pergunte qual prefere.
5. **PREVIEW no chat:** mostre, rede por rede, exatamente o que vai subir (legenda + horário), diga que
   **nada foi agendado ainda** e pergunte: "posso agendar assim?".
6. **Só depois do "sim" explícito**, agende de verdade com `createScheduledPost` (uma chamada por rede,
   com o `brandId`/`blogId` dela, a data com fuso, a legenda e o link do vídeo). Se o conector não estiver
   ligado ainda, entregue as legendas prontas pra ela colar no Metricool na mão e guie onde colar.
7. **Confirme** o que ficou agendado, rede por rede, com dia e hora. **Se o dashboard já existir**
   (Módulo 6 feito), atualize o `dados.js`: acrescente esses posts na "fila". Se ainda não existir,
   guarde mentalmente: eles entram na semeadura do Módulo 6. Nada de rede social sem o "sim" dela.

Marque o Módulo 5, comemore: "Seu conteúdo agora tem por onde sair, agendado sozinho."
