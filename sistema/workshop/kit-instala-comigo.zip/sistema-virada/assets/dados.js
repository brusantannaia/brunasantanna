// Os dados do seu painel. Você (ou o Claude, com o Metricool ligado) atualiza aqui.
window.MEUS_DADOS = {
  // A meta de 90 dias do perfil (preencha com a meta REAL do Módulo 1: descricao, o número ATUAL que a
  // pessoa te deu, o alvo, e o prazo = data de hoje + 90 dias, formato DD/MM/AAAA):
  meta: { descricao: "PREENCHA: a meta dela", atual: 0, alvo: 0, prazo: "DD/MM/AAAA" },
  resultados: [
    // { data:"2026-07-17", conteudo:"Erros ao financiar", rede:"Instagram", alcance:0 }
  ],
  fila: [
    // { data:"2026-07-20", conteudo:"Próximo post", rede:"TikTok" }
  ]
};
