# Modelo de roteiro de edição pro CapCut

Use este modelo quando o caminho for entregar um roteiro pra pessoa executar no CapCut (o aplicativo
grátis de celular). O objetivo: a pessoa segue em poucos minutos, sem pensar, e sai com o vídeo bom.

## Regras do roteiro

- Escreva CADA passo como uma ação de apertar/arrastar no app, em português de gente. Nada de tecniquês.
- Se você conseguiu analisar o vídeo (ouvir/transcrever), inclua os TEMPOS exatos (min:seg) de cada corte
  e de cada texto. Se NÃO conseguiu, monte por estrutura (ex.: "corta a saudação inicial, deixa a
  explicação dos 3 passos, corta as pausas longas") e peça pra pessoa marcar as pausas dela no app.
- Poucos passos, numerados, na ordem em que a pessoa vai executar no app (primeiro cortes, depois
  legenda, depois título, depois exportar).
- Feche sempre dizendo como exportar e conferir.

## Esqueleto (adapte ao pedido)

```
SEU ROTEIRO DE EDIÇÃO (é só seguir no CapCut)

1. ABRIR: CapCut > Novo projeto > escolhe o seu vídeo.

2. CORTES (deixar o vídeo mais rápido):
   - Corta do início até [0:04] (a saudação).
   - Corta de [0:32] a [0:38] (pausa longa).
   - (ou, sem tempos: "assiste uma vez e corta toda pausa em que você fica mais de 2 segundos sem falar")

3. LEGENDA (o texto do que você fala):
   - Toca em "Texto" > "Legendas automáticas" > Português > Gerar.
   - Confere se saiu certo; erro de palavra, toca na legenda e corrige.

4. TÍTULO (segura quem tá passando):
   - Toca em "Texto" > "Adicionar texto" e escreve: "[TÍTULO FORTE AQUI]"
   - Arrasta pro topo da tela, deixa dos [0:00] aos [0:03].

5. FORMATO: em "Proporção", escolhe 9:16 (o vertical de Reel/TikTok).

6. EXPORTAR: seta no canto de cima > Exportar. Pronto, tá no seu rolo.
```

## Prévia e ajuste

Roteiro entregue não é fim de conversa. Peça: "faz aí e me conta como ficou; se travar em qualquer passo,
me fala qual que eu te destravo". Se a pessoa mandar o resultado, olhe e sugira no máximo 1-2 ajustes de
cada vez.
